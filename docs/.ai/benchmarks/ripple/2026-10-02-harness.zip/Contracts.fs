module Contracts

open Fable.Core

type Dashboard = {
    Set: int array -> unit
    Batch: int array -> unit
    Dispose: unit -> unit
}

type Controls = {
    SetName: string -> unit
    Count: unit -> int
    Dispose: unit -> unit
}

type AsyncView = {
    Load: int -> unit
    State: unit -> string
    Cancelled: unit -> int
    Dispose: unit -> unit
}

type FailureProbe = {
    Set: int -> unit
    Calls: unit -> int
    Writes: unit -> int
    Message: string
    Button: obj
    Cleanup: unit -> unit
}

type GraphView = {
    Set: int -> unit
    Batch: int -> unit
    Value: unit -> int
    Runs: unit -> int
    Dispose: unit -> unit
}
