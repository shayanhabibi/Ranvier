export default {
  build: { lib: { entry: "generated/RippleCase.js", formats: ["es"], fileName: "fixture" }, outDir: "dist-ripple", minify: true }
};
