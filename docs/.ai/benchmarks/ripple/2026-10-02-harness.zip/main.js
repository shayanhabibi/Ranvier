import * as ranvier from "./generated/RanvierCase.js";
import * as ripple from "./generated/RippleCase.js";
import { benchmark } from "./checks.mjs";
window.comparison = { ranvier, ripple, benchmark };
