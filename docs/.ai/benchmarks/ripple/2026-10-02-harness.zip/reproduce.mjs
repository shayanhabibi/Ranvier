import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { setTimeout } from "node:timers/promises";

const cwd = fileURLToPath(new URL(".", import.meta.url));
const vite = fileURLToPath(new URL("../../../examples/Fable.Ranvier.Playground/node_modules/vite/bin/vite.js", import.meta.url));
function run(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, stdio: "inherit", windowsHide: true });
    child.once("error", reject);
    child.once("exit", code => code === 0 ? resolve() : reject(new Error(`${command} exited ${code}`)));
  });
}
try {
  await fetch("http://127.0.0.1:5181");
  throw new Error("Port 5181 is occupied; stop its existing server before reproducing.");
} catch (error) {
  if (!error.cause) throw error;
}
await run("rtk", ["proxy", "dotnet", "fable", "Comparison.fsproj", "--outDir", "generated", "--configuration", "Release"]);
await run("rtk", ["proxy", "node", vite, "build"]);
const server = spawn(process.execPath, [vite, "preview", "--host", "127.0.0.1", "--port", "5181", "--strictPort"], { cwd, stdio: "inherit", windowsHide: true });
let serverError;
server.on("error", error => { serverError = error; });
try {
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt++) {
    if (serverError) throw serverError;
    if (server.exitCode !== null) throw new Error("Preview server exited before becoming ready.");
    try { ready = (await fetch("http://127.0.0.1:5181")).ok; } catch {}
    if (ready) break;
    await setTimeout(100);
  }
  if (!ready) throw new Error("Preview server did not become ready.");
  await run("rtk", ["proxy", "node", "run.mjs", ...process.argv.slice(2)]);
} finally {
  if (server.exitCode === null) {
    await new Promise(resolve => { server.once("exit", resolve); server.kill(); });
  }
}
