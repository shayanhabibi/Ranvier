export default {
  build: { lib: { entry: "generated/RanvierCase.js", formats: ["es"], fileName: "fixture" }, outDir: "dist-ranvier", minify: true }
};
