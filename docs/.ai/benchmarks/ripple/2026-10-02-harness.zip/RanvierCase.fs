module RanvierCase

open System
open System.Threading.Tasks
open Fable.Core
open Fable.Core.TS.Dom
open global.Ranvier
open Fable.Ranvier
open Contracts

[<Emit("$0")>]
let private asTask (promise: JS.Promise<'T>) : Task<'T> = jsNative

let createDashboard (hostId: string) count =
    let graph = new Graph()
    let values = graph.Run(fun () -> Array.init count (fun _ -> createSignal 0))
    let mounted = Mount.mount graph (Dom.document.getElementById hostId).Value (fun () ->
        let children = values |> Array.map (fun source ->
            let doubled = createMemo (fun _ -> source.Value * 2)
            Dom.element "span" [] [Dom.reactiveText (fun () -> string doubled.Value)] :> Node)
        Dom.element "div" [] (List.ofArray children) :> Node)
    { Set = fun pair -> values[pair[0]].Value <- pair[1]
      Batch = fun pairs -> graph.Run(fun () -> batch(fun () ->
          for index in 0 .. 2 .. pairs.Length - 2 do values[pairs[index]].Value <- pairs[index + 1]))
      Dispose = fun () -> mounted.Dispose(); graph.Dispose() }

let createControls (hostId: string) =
    let graph = new Graph()
    let count, name = graph.Run(fun () -> createSignal 0, createSignal "world")
    let id value = Dom.attribute "data-testid" value
    let mounted = Mount.mount graph (Dom.document.getElementById hostId).Value (fun () ->
        let doubled = createMemo (fun _ -> count.Value * 2)
        Dom.element "div" [] [
            Dom.element "button" [id "increment"; Dom.on "click" (fun _ -> count.Value <- count.Value + 1)] [Dom.text "increment"]
            Dom.element "button" [id "reset"; Dom.bindProperty (fun () -> count.Value = 0) (fun el disabled -> (unbox<HTMLButtonElement> el).disabled <- disabled); Dom.on "click" (fun _ -> count.Value <- 0)] [Dom.text "reset"]
            Dom.element "output" [id "count"] [Dom.reactiveText (fun () -> string count.Value)]
            Dom.element "output" [id "doubled"] [Dom.reactiveText (fun () -> string doubled.Value)]
            Dom.element "input" [id "name"; Dom.bindProperty (fun () -> name.Value) (fun el value ->
                let input = unbox<HTMLInputElement> el
                if input.value <> value then input.value <- value);
                Dom.on "input" (fun event -> name.Value <- (unbox<HTMLInputElement> event.currentTarget.Value).value)] []
            Dom.element "output" [id "greeting"] [Dom.reactiveText (fun () -> "Hello, " + name.Value)]
        ] :> Node)
    { SetName = fun value -> name.Value <- value
      Count = fun () -> count.Peek
      Dispose = fun () -> mounted.Dispose(); graph.Dispose() }

let createAsyncView (hostId: string) (fetch: int -> JS.Promise<string>) =
    let graph = new Graph()
    let query = graph.Run(fun () -> createSignal 0)
    let mutable result = Unchecked.defaultof<AsyncMemo<string>>
    let mutable cancelled = 0
    let describe () =
        match result.TryValue with
        | Ready "" -> "idle"
        | Ready value -> "loaded:" + value
        | Pending -> if String.IsNullOrEmpty result.Peek then "loading" else "reloading:" + result.Peek
        | Failed error -> "failed:" + error.Message
    let mounted = Mount.mount graph (Dom.document.getElementById hostId).Value (fun () ->
        result <- createAsync (fun _ token ->
            let id = query.Value
            if id = 0 then Task.FromResult ""
            else
                token.Register(fun () -> cancelled <- cancelled + 1) |> ignore
                asTask (fetch id))
        Dom.element "output" [] [Dom.reactiveText describe] :> Node)
    { Load = fun id -> query.Value <- id
      State = describe
      Cancelled = fun () -> cancelled
      Dispose = fun () -> mounted.Dispose() }

let failedFactory (hostId: string) =
    let graph = new Graph()
    let source = graph.Run(fun () -> createSignal 0)
    let mutable writes, calls = 0, 0
    let mutable button = Unchecked.defaultof<HTMLElement>
    let mutable message = ""
    try
        Mount.mount graph (Dom.document.getElementById hostId).Value (fun () ->
            createEffectOn (fun () -> source.Value) (fun _ -> writes <- writes + 1)
            button <- Dom.element "button" [Dom.on "click" (fun _ -> calls <- calls + 1)] []
            failwith "factory failed") |> ignore
    with error -> message <- error.Message
    { Set = fun value -> source.Value <- value
      Calls = fun () -> calls
      Writes = fun () -> writes
      Message = message
      Button = box button
      Cleanup = fun () -> graph.Dispose() }

let createGraph () =
    let graph = new Graph()
    let mutable source = Unchecked.defaultof<Signal<int>>
    let mutable value, runs = 0, 0
    graph.Run(fun () ->
        source <- createSignal 0
        let left = createMemo (fun _ -> source.Value + 1)
        let right = createMemo (fun _ -> source.Value * 2)
        let merged = createMemo (fun _ -> left.Value + right.Value)
        createEffectOn (fun () -> merged.Value) (fun result -> value <- result; runs <- runs + 1))
    { Set = fun input -> source.Value <- input
      Batch = fun input -> graph.Run(fun () -> batch(fun () -> source.Value <- input; source.Value <- input + 1))
      Value = fun () -> value
      Runs = fun () -> runs
      Dispose = fun () -> graph.Dispose() }

let createErrorGraph () =
    let graph = new Graph()
    let mutable source = Unchecked.defaultof<Signal<int>>
    let mutable value, runs = 0, 0
    graph.Run(fun () ->
        source <- createSignal 0
        createEffect(fun () -> if source.Value = 2 then failwith "effect failed")
        createEffect(fun () -> value <- source.Value; runs <- runs + 1))
    { Set = fun input -> source.Value <- input
      Batch = fun _ -> ()
      Value = fun () -> value
      Runs = fun () -> runs
      Dispose = fun () -> graph.Dispose() }
