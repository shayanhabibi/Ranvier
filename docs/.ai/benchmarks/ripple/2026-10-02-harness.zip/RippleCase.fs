module RippleCase

open System
open Fable.Core
open Fable.Ripple
open Fable.Ripple.Dom
open Contracts

type private RemoteData =
    | NotAsked
    | Loading
    | Reloading of string
    | Loaded of string
    | Failed of string

let createDashboard (hostId: string) count =
    let values = Array.init count (fun _ -> Var.create 0)
    let mounted = Html.mount hostId (fun () ->
        Html.div [
            for source in values do
                let doubled = Signal.map (fun value -> value * 2) source
                yield Html.span [Html.text (fun () -> string doubled.Value)]
        ])
    { Set = fun pair -> values[pair[0]].Value <- pair[1]
      Batch = fun pairs -> Signal.batch(fun () ->
          for index in 0 .. 2 .. pairs.Length - 2 do values[pairs[index]].Value <- pairs[index + 1])
      Dispose = fun () -> mounted.Dispose() }

let createControls (hostId: string) =
    let count, name = Var.create 0, Var.create "world"
    let id (value: string) = attr.custom("data-testid", value)
    let mounted = Html.mount hostId (fun () ->
        let doubled = Signal.map (fun value -> value * 2) count
        Html.div [
            Html.button [id "increment"; on.click(fun _ -> count.Value <- count.Value + 1); Html.text "increment"]
            Html.button [id "reset"; attr.disabled(fun () -> count.Value = 0); on.click(fun _ -> count.Value <- 0); Html.text "reset"]
            Html.output [id "count"; Html.text (fun () -> string count.Value)]
            Html.output [id "doubled"; Html.text (fun () -> string doubled.Value)]
            Html.input [id "name"; attr.bindValue name]
            Html.output [id "greeting"; Html.text (fun () -> "Hello, " + name.Value)]
        ])
    { SetName = fun value -> name.Value <- value
      Count = fun () -> count.Value
      Dispose = fun () -> mounted.Dispose() }

let createAsyncView (hostId: string) (fetch: int -> JS.Promise<string>) =
    let state = Var.create NotAsked
    let mutable generation = 0
    let describe () =
        match state.Value with
        | NotAsked -> "idle"
        | Loading -> "loading"
        | Reloading value -> "reloading:" + value
        | Loaded value -> "loaded:" + value
        | Failed error -> "failed:" + error
    let load id =
        generation <- generation + 1
        let mine = generation
        state.Value <-
            match state.Value with
            | Loaded previous | Reloading previous -> Reloading previous
            | _ -> Loading
        fetch id
        |> Promise.map (fun value -> if mine = generation then state.Value <- Loaded value)
        |> Promise.catch (fun error -> if mine = generation then state.Value <- Failed error.Message)
        |> ignore
    let mounted = Html.mount hostId (fun () -> Html.output [Html.text describe])
    { Load = load
      State = describe
      Cancelled = fun () -> 0
      Dispose = fun () -> mounted.Dispose() }

let failedFactory (hostId: string) =
    let source = Var.create 0
    let mutable writes, calls = 0, 0
    let mutable button = Unchecked.defaultof<Browser.Types.HTMLElement>
    let mutable effect = Unchecked.defaultof<IDisposable>
    let mutable message = ""
    try
        Html.mount hostId (fun () ->
            effect <- Signal.effect(fun () -> source.Value |> ignore; writes <- writes + 1)
            let child = Html.button [on.click(fun _ -> calls <- calls + 1); attr.ref(fun el -> button <- el)]
            Html.div [child; failwith "factory failed"]) |> ignore
    with error -> message <- error.Message
    { Set = fun value -> source.Value <- value
      Calls = fun () -> calls
      Writes = fun () -> writes
      Message = message
      Button = box button
      Cleanup = fun () -> effect.Dispose() }

let createGraph () =
    let source = Var.create 0
    let mutable value, runs = 0, 0
    let _, scope = Signal.root(fun () ->
        let left = Signal.map (fun input -> input + 1) source
        let right = Signal.map (fun input -> input * 2) source
        let merged = Signal.computed(fun () -> left.Value + right.Value)
        Signal.autorun(fun () -> value <- merged.Value; runs <- runs + 1))
    { Set = fun input -> source.Value <- input
      Batch = fun input -> Signal.batch(fun () -> source.Value <- input; source.Value <- input + 1)
      Value = fun () -> value
      Runs = fun () -> runs
      Dispose = fun () -> scope.Dispose() }

let createErrorGraph () =
    let source = Var.create 0
    let mutable value, runs = 0, 0
    let _, scope = Signal.root(fun () ->
        Signal.autorun(fun () -> if source.Value = 2 then failwith "effect failed")
        Signal.autorun(fun () -> value <- source.Value; runs <- runs + 1))
    { Set = fun input -> source.Value <- input
      Batch = fun _ -> ()
      Value = fun () -> value
      Runs = fun () -> runs
      Dispose = fun () -> scope.Dispose() }
