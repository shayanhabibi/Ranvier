import { createRequire } from "node:module";
import { writeFile } from "node:fs/promises";
import { cpus } from "node:os";
import { correctness } from "./checks.mjs";
const require = createRequire(new URL("../../../examples/Fable.Ranvier.Playground/package.json", import.meta.url));
const { chromium } = require("@playwright/test");
const browser = await chromium.launch();
const output = { date: new Date().toISOString(), browser: browser.version(), node: process.version, cpu: cpus()[0].model, fable: "5.18.0", ripple: "1.0.0-beta.6", rippleDom: "1.0.0-beta.7", correctness: {}, samples: {}, options: { cells: 1000, lifecycleCycles: 50, sparseWrites: 100000, batchCells: 100, batches: 2000, graphWrites: 100000, asyncWrites: 20000, warmups: 5, rounds: 25 }, console: [] };
try {
  for (const library of ["ranvier", "ripple"]) {
    const page = await browser.newPage();
    page.on("pageerror", error => output.console.push({ library, error: error.message }));
    await page.goto("http://127.0.0.1:5181");
    await page.waitForFunction(() => window.comparison);
    output.correctness[library] = await page.evaluate(correctness, library);
    console.log(library, "probes:", output.correctness[library].filter(x => x.pass).length, "/", output.correctness[library].filter(x => x.pass !== undefined).length);
    for (const result of output.correctness[library].filter(x => x.pass === false)) console.log(library, "DIFFERENCE", JSON.stringify(result));
    await page.close();
  }
  if (!process.argv.includes("--checks-only")) {
    const workloads = ["mount-50x1000", "dispose-50x1000", "sparse-100000", "batch-2000x100", "diamond-100000", "async-20000"];
    const pages = {};
    for (const library of ["ranvier", "ripple"]) {
      pages[library] = await browser.newPage();
      await pages[library].goto("http://127.0.0.1:5181");
      await pages[library].waitForFunction(() => window.comparison);
    }
    for (const workload of workloads) {
      output.samples[workload] = { ranvier: [], ripple: [] };
      for (let round = -output.options.warmups; round < output.options.rounds; round++) {
        const order = round % 2 === 0 ? ["ranvier", "ripple"] : ["ripple", "ranvier"];
        for (const library of order) {
          const elapsed = await pages[library].evaluate(async args => {
            return window.comparison.benchmark(args.library, args.workload, args.options);
          }, { library, workload, options: output.options });
          if (round >= 0) output.samples[workload][library].push(elapsed);
        }
      }
      console.log(workload, JSON.stringify(Object.fromEntries(Object.entries(output.samples[workload]).map(([lib, values]) => {
        const sorted = [...values].sort((a, b) => a - b);
        return [lib, { medianMs: sorted[Math.floor(sorted.length / 2)], p95Ms: sorted[Math.ceil(sorted.length * 0.95) - 1] }];
      }))));
    }
  }
} finally {
  await browser.close();
  await writeFile(new URL(process.argv.includes("--checks-only") ? "results-checks.json" : "results.json", import.meta.url), JSON.stringify(output, null, 2));
}
