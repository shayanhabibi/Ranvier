export async function correctness(library) {
  const api = window.comparison[library];
  const results = [];
  const check = (name, expected, actual, classification = "common behavior") => {
    results.push({ name, expected, actual, pass: JSON.stringify(expected) === JSON.stringify(actual), classification });
  };
  const host = document.getElementById("host");
  const other = document.getElementById("other");
  const drain = async () => { for (let i = 0; i < 30; i++) await Promise.resolve(); };
  let fixture = api.createControls("host");
  const find = id => host.querySelector(`[data-testid="${id}"]`);
  check("initial reset is disabled", true, find("reset").disabled);
  const root = host.firstChild;
  const countText = find("count").firstChild;
  const input = find("name");
  const retainedButton = find("increment");
  retainedButton.click();
  check("click updates count and derived output", ["1", "2", false], [find("count").textContent, find("doubled").textContent, find("reset").disabled]);
  check("counter root and text retain identity", true, root === host.firstChild && countText === find("count").firstChild);
  input.focus();
  input.value = "abcdef";
  input.setSelectionRange(2, 2);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  check("input updates greeting and keeps focus/caret", ["Hello, abcdef", true, 2, 2], [find("greeting").textContent, document.activeElement === input, input.selectionStart, input.selectionEnd]);
  fixture.SetName("Ada");
  check("programmatic name writes the live input property", ["Ada", "Hello, Ada"], [input.value, find("greeting").textContent]);
  const before = fixture.Count();
  fixture.Dispose();
  fixture.Dispose();
  check("repeated mount disposal removes its root", 0, host.childNodes.length);
  retainedButton.click();
  check("retained detached button is inert", before, fixture.Count(), "lifecycle safety");
  fixture = api.createControls("host");
  other.appendChild(host.firstChild);
  let movedError = null;
  try { fixture.Dispose(); } catch (error) { movedError = String(error); }
  check("moved root is removed safely on disposal", [0, null], [other.childNodes.length, movedError], "lifecycle safety");
  other.replaceChildren();
  host.replaceChildren(document.createTextNode("preserved"));
  const failure = api.failedFactory("host");
  check("factory failure escapes without altering host", ["factory failed", "preserved"], [failure.Message, host.textContent]);
  failure.Set(1);
  failure.Button.click();
  check("failed factory cleans reactive work and listener", [1, 0], [failure.Writes(), failure.Calls()], "lifecycle safety");
  failure.Cleanup();
  host.replaceChildren();
  const graph = api.createGraph();
  graph.Set(4);
  check("diamond produces one coherent result", [13, 2], [graph.Value(), graph.Runs()]);
  graph.Set(4);
  check("equal write does not rerun graph effect", 2, graph.Runs());
  graph.Batch(10);
  check("batch coalesces two source writes", [34, 3], [graph.Value(), graph.Runs()]);
  graph.Dispose();
  graph.Set(20);
  check("disposed graph effects stop", 34, graph.Value());
  const errorGraph = api.createErrorGraph();
  errorGraph.Set(1);
  let thrown = null;
  try { errorGraph.Set(2); } catch (error) { thrown = error.message; }
  check("one failing effect does not strand healthy sibling", 2, errorGraph.Value(), "error isolation");
  results.push({ name: "synchronous effect error policy", actual: thrown, classification: "observation" });
  errorGraph.Set(3);
  check("healthy effect recovers on subsequent update", 3, errorGraph.Value());
  errorGraph.Set(4); errorGraph.Set(5);
  check("healthy effect remains live through later writes", 5, errorGraph.Value(), "error isolation");
  errorGraph.Dispose();

  const pending = new Map();
  const request = id => {
    if (id === 10) throw new Error("request setup failed");
    let outerResolve, outerReject, innerResolve, innerReject;
    const outer = new Promise((resolve, reject) => { outerResolve = resolve; outerReject = reject; });
    const inner = new Promise((resolve, reject) => { innerResolve = resolve; innerReject = reject; });
    const record = { outerResolve, outerReject, innerResolve, innerReject };
    pending.set(id, record);
    return outer.then(() => inner).then(value => {
      if (value === "throw-in-map") throw new Error("mapping failed");
      return value;
    });
  };
  const view = api.createAsyncView("host", request);
  await drain();
  check("async starts idle", "idle", host.textContent);
  view.Load(1);
  check("request enters loading", "loading", host.textContent);
  pending.get(1).outerResolve();
  await drain();
  check("outer completion waits for nested promise", "loading", host.textContent);
  pending.get(1).innerResolve("Ada");
  await drain();
  check("nested promise updates settled DOM", "loaded:Ada", host.textContent);
  view.Load(2);
  check("refresh retains previous result while loading", "reloading:Ada", host.textContent);
  view.Load(3);
  pending.get(3).outerResolve(); pending.get(3).innerResolve("Grace");
  await drain();
  pending.get(2).outerResolve(); pending.get(2).innerResolve("obsolete");
  await drain();
  check("older success cannot overwrite newer nested response", "loaded:Grace", host.textContent);
  view.Load(4); view.Load(5);
  pending.get(5).outerResolve(); pending.get(5).innerResolve("Linus");
  await drain();
  pending.get(4).outerReject(new Error("obsolete failure"));
  await drain();
  check("older rejection cannot replace current success", "loaded:Linus", host.textContent);
  view.Load(6);
  pending.get(6).outerResolve(); pending.get(6).innerReject(new Error("inner failed"));
  await drain();
  check("nested rejection becomes a visible error", "failed:inner failed", host.textContent);
  view.Load(7);
  pending.get(7).outerResolve(); pending.get(7).innerResolve("Recovered");
  await drain();
  check("successful request recovers after rejection", "loaded:Recovered", host.textContent);
  view.Load(8);
  pending.get(8).outerResolve(); pending.get(8).innerResolve("throw-in-map");
  await drain();
  check("exception thrown inside promise mapping becomes visible", "failed:mapping failed", host.textContent);
  let setupError = null;
  try { view.Load(10); } catch (error) { setupError = error.message; }
  check("synchronous request setup exception becomes visible", "failed:request setup failed", host.textContent, "async error capability");
  results.push({ name: "synchronous request setup error observation", actual: setupError, classification: "observation" });
  view.Load(9);
  pending.get(9).outerResolve();
  await drain();
  const retainedOutput = host.firstChild;
  const beforeDisposeText = retainedOutput.textContent;
  view.Dispose();
  const stateAtDisposal = view.State();
  pending.get(9).innerResolve("too late");
  await drain();
  check("pending promise cannot publish state after disposal", stateAtDisposal, view.State(), "async lifetime safety");
  check("detached async DOM stops updating", beforeDisposeText, retainedOutput.textContent);
  check("superseded and disposed flights signal cancellation", true, view.Cancelled() >= 3, "native cancellation capability");
  check("async disposal removes mounted DOM", 0, host.childNodes.length);
  return results;
}

export async function benchmark(library, workload, options) {
  const api = window.comparison[library];
  const host = document.getElementById("host");
  host.replaceChildren();
  let elapsed;
  if (workload === "diamond-100000") {
    const graph = api.createGraph();
    const start = performance.now();
    for (let i = 1; i <= options.graphWrites; i++) graph.Set(i);
    elapsed = performance.now() - start;
    if (graph.Value() !== options.graphWrites * 3 + 1 || graph.Runs() !== options.graphWrites + 1) throw new Error("incorrect graph result");
    graph.Dispose();
  } else if (workload === "async-20000") {
    let resolve;
    const view = api.createAsyncView("host", () => new Promise(done => { resolve = done; }));
    for (let i = 0; i < 30; i++) await Promise.resolve();
    const start = performance.now();
    for (let i = 1; i <= options.asyncWrites; i++) {
      view.Load(i);
      resolve(String(i));
      const expected = "loaded:" + i;
      let spins = 0;
      while (host.textContent !== expected && spins++ < 100) await Promise.resolve();
      if (host.textContent !== expected) throw new Error("async DOM failed to settle");
    }
    elapsed = performance.now() - start;
    view.Dispose();
  } else if (workload === "mount-50x1000" || workload === "dispose-50x1000") {
    elapsed = 0;
    for (let cycle = 0; cycle < options.lifecycleCycles; cycle++) {
      const start = performance.now();
      const dashboard = api.createDashboard("host", options.cells);
      const mountTime = performance.now() - start;
      if (host.querySelectorAll("span").length !== options.cells) throw new Error("incorrect mounted cell count");
      const disposeStart = performance.now();
      dashboard.Dispose();
      const disposeTime = performance.now() - disposeStart;
      if (host.childNodes.length !== 0) throw new Error("disposed root remains");
      elapsed += workload === "mount-50x1000" ? mountTime : disposeTime;
    }
  } else {
    const dashboard = api.createDashboard("host", options.cells);
    const pair = [0, 0];
    const pairs = [];
    for (let i = 0; i < options.batchCells; i++) pairs.push(i, 0);
    const start = performance.now();
    if (workload === "sparse-100000") {
      for (let i = 0; i < options.sparseWrites; i++) {
        pair[0] = i % options.cells; pair[1] = Math.floor(i / options.cells) + 1;
        dashboard.Set(pair);
      }
    } else if (workload === "batch-2000x100") {
      for (let batch = 1; batch <= options.batches; batch++) {
        for (let i = 1; i < pairs.length; i += 2) pairs[i] = batch;
        dashboard.Batch(pairs);
      }
    }
    elapsed = performance.now() - start;
    const cells = [...host.querySelectorAll("span")];
    for (let i = 0; i < cells.length; i++) {
      const expected = workload === "sparse-100000"
        ? Math.max(0, Math.floor((options.sparseWrites - 1 - i) / options.cells) + 1) * 2
        : (i < options.batchCells ? options.batches * 2 : 0);
      if (cells[i].textContent !== String(expected)) throw new Error("incorrect final cell " + i);
    }
    dashboard.Dispose();
  }
  return elapsed;
}
